package peersim.pastry;

import peersim.core.*;
import peersim.config.Configuration;
import peersim.edsim.EDSimulator;
import java.math.*;
import java.util.*;


public class Consulta implements Control{

    private final static String PAR_PROT = "protocol";
    private final int pid;
    //private ArrayList<String> tem;
    private String prefix;
    Node consulta;

    public Consulta(String prefix) {
        this.prefix = prefix;
        //System.out.println("prefix:" +prefix);
        pid = Configuration.getPid(prefix + "." + PAR_PROT);
    }

    public Message consultaMensaje(){
    	Message m = Message.makeQuery("Mensaje 7");
    	m.timestamp = CommonState.getTime();

    	if (CommonState.r.nextInt(100) < 100){
        	m.dest = new BigInteger(MSPastryCommonConfig.BITS, CommonState.r);
        	
        }
        else{
        	m.dest = ((MSPastryProtocol) (Network.get(CommonState.r.nextInt(
                     Network.size())).getProtocol(pid))).nodeId;
        
        }
    	
    	//temp=m.body.toString(); 
    	System.out.print("Buscando: "+m.body+"\n");
        //System.out.println("\n[ LLEGA ]\t[ Id = "+consulta.getID()+", Consulta = "+m.body+" ]");
        return m;

    }


    public boolean execute(){
    	
    	consulta = Network.get(CommonState.r.nextInt(Network.size()));
    	//System.out.print("mensaje consulta execute: "+consulta);
    	EDSimulator.add(0, consultaMensaje(), consulta, pid);
    	return false;
    } 

}